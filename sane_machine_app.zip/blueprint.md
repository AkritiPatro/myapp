# Sane Machine - Project Blueprint

## Overview

This document outlines the features, design, and deployment details for the Sane Machine Flutter application.

## Deployment

The application is deployed to Firebase Hosting and is publicly accessible.

*   **Live Website URL:** [https://sane-machine-5a2d5.web.app](https://sane-machine-5a2d5.web.app)

## Features Implemented

*   User Authentication (Sign Up & Sign In)
*   Device Management (Add, Rename, Delete, Toggle Status)
*   Real-time device status updates.
*   Dark/Light Theme toggle.
*   Navigation to a Chatbot screen.
*   User Logout functionality.
*   Personalized welcome message with the user's name.
*   Visually distinct UI for dark and light modes with gradients and custom fonts.
*   Responsive `AppBar` with always-visible action icons.

## Style & Design

*   **Typography:** Google Fonts (`Poppins`).
*   **Color Scheme:**
    *   **Light Mode:** Deep Purple primary, with light grey backgrounds.
    *   **Dark Mode:** Teal Accent primary, with dark grey and black backgrounds.
*   **UI Components:** Custom-styled Cards, Buttons, Dialogs, and a gradient background.
